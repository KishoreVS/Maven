package com.pwd.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.pwd.entities.Employee;

@Repository
@Transactional
public class EmployeeDAOImpl implements EmployeeDAO{

	@PersistenceContext
	private EntityManager entityManager;

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
  
	public void addEmployee(Employee employee) {
	
		entityManager.persist(employee);
		System.out.println("*************");
	}

	public Employee fetchEmployeeById(int employeeId) {
	   return entityManager.find(Employee.class,employeeId);
	}

	
	public void deleteEmployeeById(int employeeId) {
	
		Employee employee = entityManager.find(Employee.class,employeeId);
		if(employee!=null)
		{
			entityManager.remove(employee);
		}
	}

	
	public void updateEmployeeEmailById(String newEmail, int employeeId) {
		
		Employee employee = entityManager.find(Employee.class,employeeId);
          if(employee!=null)
          {
        	  employee.setEmail(newEmail);
        	  entityManager.merge(employee);
          }
		
	}

	public List<Employee> getAllEmployeeInfo() {
		
		Query query = entityManager.createQuery("From Employee");
		List<Employee> empList = query.getResultList();
		return empList;
	}

}
