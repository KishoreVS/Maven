package com.pwd.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.pwd.service.EmployeeService;

import com.pwd.entities.Employee;

public class Test
{
   public static void main(String[] args)
  {
	   ApplicationContext ctx = new ClassPathXmlApplicationContext("Beans.xml");
		EmployeeService employeeService =  ctx.getBean("employeeService",EmployeeService.class);
		createEmployee(employeeService);
		//getEmployeeById(employeeService);
		//fetchAllEmployeesInfo(employeeService);
		//employeeService.updateEmployeeEmailById("aka1@gmail.com", 1);
		//employeeService.deleteEmployeeById(1);
		}
	private static void fetchAllEmployeesInfo(EmployeeService employeeService) {
		List<Employee> empList = employeeService.getAllEmployeeInfo();
		for (Employee employee : empList) {
			System.out.println(employee.getEmployeeId()+"\t"+employee.getEmployeeName()+"\t"+employee.getEmail()+"\t"+employee.getGender()+"\t"+employee.getSalary());
		}}
	private static void getEmployeeById(EmployeeService employeeService) {
		Employee employee = employeeService.fetchEmployeeById(2);
		System.out.println(employee.getEmployeeId()+"\t"+employee.getEmployeeName()+"\t"+employee.getEmail()+"\t"+employee.getGender()+"\t"+employee.getSalary());
	}
	private static void createEmployee(EmployeeService employeeService) {
		Employee employee = new Employee();
		employee.setEmail("deepu@gmail.com");
		employee.setEmployeeName("deepu");
		employee.setGender("female");
		employee.setSalary(500.00);
		
		employeeService.addEmployee(employee);
	}
  }

